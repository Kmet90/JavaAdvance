package ExercisesDefiningClasses.Google07;

public class Parents {
    private String parentName;
    private String parentBirth;


    public Parents(String parentName, String parentBirth) {
        this.parentName = parentName;
        this.parentBirth = parentBirth;
    }

    public String getParentName() {
        return this.parentName;
    }

    public String getParentBirth() {
        return this.parentBirth;
    }
}
