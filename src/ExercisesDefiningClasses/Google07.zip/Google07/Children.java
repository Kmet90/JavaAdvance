package ExercisesDefiningClasses.Google07;

public class Children {
    private String childName;
    private String childBirth;

    public Children (String childName, String childBirth){
        this.childName = childName;
        this.childBirth = childBirth;
    }

    public String getChildName() {
        return this.childName;
    }

    public String getChildBirth() {
        return this.childBirth;
    }
}
